// this component is used only for building vux.css
<style>
@import './index.less';
</style>
<template>
<div>
  <divider>Alipay: I have bottom line</divider>
  <divider>我是有底线的</divider>
</div>
</template>

<script>
import { Divider } from '../components'

export default {
  components: {
    Divider
  }
}
</script>
<template>
  <div>
    <img src="../assets/demo/wechat_pay_10_24.jpg">
    <divider>Proudly sponsored by </divider>
  </div>
</template>

<script>
import { Divider } from '../components'

export default {
  components: {
    Divider
  }
}
</script>

<template>
  <div>
    <group title="single column">
      <popup-picker :title="title1" :data="list1" :value="value1" @on-show="onShow" @on-hide="onHide"></popup-picker>
    </group>
    <br>
    <div class="picker-buttons">
      <x-button type="primary" @click="changeList10">重新赋值列表</x-button>
      <x-button type="primary" @click="changeList11">push方式更改列表</x-button>
    </div>
    <group title="double columns">
      <popup-picker :title="title2" :data="list2" :value="value2"></popup-picker>
    </group>
    <br>

    <group title="chained columns">
      <popup-picker :title="title3" :data="list3" :columns="3" :value="value3" ref="picker3" @on-hide="onPopPickerHide"></popup-picker>
      <cell title="获取值对应的值" :value="value8"></cell>
      <cell title="获取值对应的文字" :value="nameValues"></cell>
      <popup-picker :title="title4" :data="list3" :columns="3" :value="value4" show-name></popup-picker>
    </group>

    <br>
    <div class="picker-buttons">
      <x-button type="primary" @click="changeList21">push方式更改列表</x-button>
    </div>

    <br>
    <divider ref="kkk">Control the visibility of popup-picker 隐藏cell</divider>
    <div style="margin: 0 15px;">
      <x-button @click="onShowPopupPicker(true)" type="primary">Show PopupPicker. value: {{value5}}</x-button>
    </div>
    <group>
      <popup-picker :show="showPopupPicker" title="TEST" :showCell="false" :data="[['1', '2', '3', '4', '5']]" :value="value5" @on-shadow-change="changeList20" @on-ok="getValue" @on-hide="showPopupPicker=false"></popup-picker>
    </group>

    <br>
    <br>
    <br>

  </div>
</template>

<script>
import { PopupPicker, Group, Cell, Picker, XButton, Divider,  XSwitch } from '../components'

export default {
  components: {
    PopupPicker,
    Group,
    Picker,
    XButton,
    Divider,
    Cell,
    XSwitch
  },
  methods: {
    //on-hide(ture是确定false是取消，当前的值)
    onPopPickerHide(closeType,val){
      if(closeType) this.value8 = val.join('')
      this.nameValues=this.$refs.picker3.getNameValues()
    },
    changeList10 () {
      this.list1 = [['小米1', 'iPhone1', '华为1', '情怀1', '三星1', '其他1', '不告诉你1']]
    },
    changeList11 () {
      this.list1[0].push('我是push条目')
    },
    changeList20 (val) {
      console.log('你当前选择的是：'+val)
    },
    changeList21 () {
      this.list3.push({
        name: '美国002_007',
        value: '0007',
        parent: 'usa002'
      })
    },
    onShow () {
      console.log('on show')
    },
    onHide (type) {
      console.log('on hide', type)
    },
    onShowPopupPicker(is){
      this.showPopupPicker=is
    },
    getValue(val){
      this.value5=val;
    }
  },
  mounted(){
    // this.NameValues=this.$refs.picker3.getNameValues()
  },
  data () {
    return {
      nameValues: '',
      title1: '手机机型',
      title2: '详细机型',
      title3: '联动显示值',
      title4: '联动显示文字',
      list1: [['小米', 'iPhone', '华为', '情怀', '三星', '其他', '不告诉你']],
      list2: [['小米', 'iPhone', '华为', '情怀', '三星', '其他', '不告诉你'], ['小米1', 'iPhone2', '华为3', '情怀4', '三星5', '其他6', '不告诉你7']],
      list3: [{
        name: '中国',
        value: 'china',
        parent: 0
      }, {
        name: '美国',
        value: 'USA',
        parent: 0
      }, {
        name: '广东',
        value: 'china001',
        parent: 'china'
      }, {
        name: '广西',
        value: 'china002',
        parent: 'china'
      }, {
        name: '美国001',
        value: 'usa001',
        parent: 'USA'
      }, {
        name: '美国002',
        value: 'usa002',
        parent: 'USA'
      }, {
        name: '广州',
        value: 'gz',
        parent: 'china001'
      }, {
        name: '深圳',
        value: 'sz',
        parent: 'china001'
      }, {
        name: '广西001',
        value: 'gx001',
        parent: 'china002'
      }, {
        name: '广西002',
        value: 'gx002',
        parent: 'china002'
      }, {
        name: '美国001_001',
        value: '0003',
        parent: 'usa001'
      }, {
        name: '美国001_002',
        value: '0004',
        parent: 'usa001'
      }, {
        name: '美国002_001',
        value: '0005',
        parent: 'usa002'
      }, {
        name: '美国002_002',
        value: '0006',
        parent: 'usa002'
      }],
      value1: ['iPhone'],
      value2: ['iPhone', '华为3'],
      value3: [],
      value4: [],
      showPopupPicker: false,
      value5: ['2'],
      switch6: false,
      value6: [],
      value8:''
    }
  }
}
</script>

<style scoped>
.picker-buttons {
  margin: 0 15px;
}
</style>


<template>
  <div>
    <br>
    <div class="reddot-demo vux-reddot">Hi, you got a new message </div>
    <br>
    <div class="reddot-demo vux-reddot-border">中文文字</div>
    <br>
    <div class="reddot-demo vux-reddot-s">small dot</div>
  </div>
</template>

<style scoped>
.reddot-demo {
  display: inline-block
}
</style>

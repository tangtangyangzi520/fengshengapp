<template>
  <div class="weui_cells_title">
    <slot></slot>
  </div>
</template>

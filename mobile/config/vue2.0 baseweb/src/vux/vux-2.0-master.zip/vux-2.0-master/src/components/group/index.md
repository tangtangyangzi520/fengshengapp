[zh-CN]
`Group`是一个特殊的表单`wrapper`组件，主要用于将表单分组，单个表单元素也算一组。所以常见的`行内`组件都`必须`作为`Group`的子组件。

包括：

+ Cell
+ XInput
+ XTextarea
+ Switch
+ Calendar
+ XNumber
+ Radio
+ Address
+ Datetime
+ Selector

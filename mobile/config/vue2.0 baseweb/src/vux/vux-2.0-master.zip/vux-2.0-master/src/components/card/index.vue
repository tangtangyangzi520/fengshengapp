<template>
	<div class="weui_panel weui_panel_access">
    <div class="weui_panel_hd" v-if="header && header.title" v-html="header.title" @click="$emit('on-click-header')"></div>
    <slot name="header"></slot>
    <div class="weui_panel_bd">
      <div class="vux-card-content"><slot name="content"></slot></div>
    </div>
    <a class="weui_panel_ft" href="javascript:" v-if="footer && footer.title" v-html="footer.title" @click="onClickFooter"></a>
    <slot name="footer"></slot>
  </div>
</template>

<script>
import { go } from '../../libs/router'

export default {
  props: {
    header: Object,
    footer: Object
  },
  methods: {
    onClickFooter () {
      this.footer.link && go(this.footer.link, this.$router)
      this.$emit('on-click-footer')
    }
  }
}
</script>

<style lang="less">
@import '../../styles/weui/widget/weui_panel/weui_panel';
</style>
